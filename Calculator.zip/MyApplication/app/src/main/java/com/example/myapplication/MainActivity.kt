package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private var currentNumber: String = ""
    private var result: Double = 0.0
    private var lastOperator: Char = ' '

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.workingsTV)
        val btnEquals: ImageButton = findViewById(R.id.buttonEqual)

        val numberzero: ImageButton = findViewById(R.id.numberzero)
        val numberone: ImageButton = findViewById(R.id.numberone)
        val numbertwo: ImageButton = findViewById(R.id.numbertwo)
        val numberthree: ImageButton = findViewById(R.id.numberthree)
        val numberfour: ImageButton = findViewById(R.id.numberfour)
        val numberfive: ImageButton = findViewById(R.id.numberfive)
        val numbersix: ImageButton = findViewById(R.id.numbersix)
        val numberseven: ImageButton = findViewById(R.id.numberseven)
        val numbereight: ImageButton = findViewById(R.id.numbereight)
        val numbernine: ImageButton = findViewById(R.id.numbernine)
        val decimal: ImageButton = findViewById(R.id.decimal)

        val buttonClear: ImageButton = findViewById(R.id.imageButton17)
        val buttonPlus: ImageButton = findViewById(R.id.imageButton4)
        val buttonMinus: ImageButton = findViewById(R.id.imageButton5)
        val buttonMultiply: ImageButton = findViewById(R.id.imageButton6)
        val buttonDivide: ImageButton = findViewById(R.id.imageButton7)
        val buttonPercent: ImageButton = findViewById(R.id.imageButton19)
        val buttonPlusMinus: ImageButton = findViewById(R.id.imageButton18)

        numberzero.setOnClickListener { appendNumber("0") }
        numberone.setOnClickListener { appendNumber("1") }
        numbertwo.setOnClickListener { appendNumber("2") }
        numberthree.setOnClickListener { appendNumber("3") }
        numberfour.setOnClickListener { appendNumber("4") }
        numberfive.setOnClickListener { appendNumber("5") }
        numbersix.setOnClickListener { appendNumber("6") }
        numberseven.setOnClickListener { appendNumber("7") }
        numbereight.setOnClickListener { appendNumber("8") }
        numbernine.setOnClickListener { appendNumber("9") }
        decimal.setOnClickListener { appendNumber(".") }

        buttonPlus.setOnClickListener {
            performOperation('+')
        }

        buttonMinus.setOnClickListener {
            performOperation('-')
        }

        buttonMultiply.setOnClickListener {
            performOperation('*')
        }

        buttonClear.setOnClickListener {
            currentNumber = ""
            result = 0.0
            lastOperator = ' '
            textView.text = "0"
        }

        buttonPlusMinus.setOnClickListener {
            currentNumber = if (currentNumber.startsWith("-")) {
                currentNumber.removePrefix("-")
            } else {
                "-$currentNumber"
            }
            textView.text = currentNumber
        }

        buttonPercent.setOnClickListener {
            if (currentNumber.isNotEmpty()) {
                currentNumber = (currentNumber.toDouble() / 100).toString()
                textView.text = currentNumber
            }
        }

        buttonDivide.setOnClickListener {
            performOperation('/')
        }

        btnEquals.setOnClickListener {
            if (currentNumber.isNotEmpty()) {
                when (lastOperator) {
                    '+' -> result += currentNumber.toInt()
                    '-' -> result -= currentNumber.toInt()
                    '*' -> result *= currentNumber.toInt()
                    '/' -> {
                        if (currentNumber.toInt() != 0) {
                            result /= currentNumber.toInt()
                        } else {
                            textView.text = "" // Handle division by zero
                            currentNumber = ""
                            return@setOnClickListener
                        }
                    }
                }

                lastOperator = ' '  // Reset the operator
                currentNumber = ""  // Clear current input
                textView.text = result.toString()  // Display the result
            }
        }

    }
    private fun performOperation(operator: Char) {
        if (currentNumber.isNotEmpty()) {
            when (lastOperator) {
                '+' -> result += currentNumber.toInt()
                '-' -> result -= currentNumber.toInt()
                '*' -> result *= currentNumber.toInt()
                '/' -> {
                    if (currentNumber.toInt() != 0) {
                        result /= currentNumber.toInt()
                    } else {
                        currentNumber = ""
                        return
                    }
                }
                ' ' -> result = currentNumber.toDouble()
            }

            lastOperator = operator
            currentNumber = ""
            textView.text = result.toString()
        } else {
            lastOperator = operator
        }
    }
    private fun appendNumber(number: String) {
        currentNumber += number
        textView.text = currentNumber
    }

}